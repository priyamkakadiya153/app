'use client';
    
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { PageHeader } from '@/components/page-header';
import { useFirestore, useDoc, useCollection, useMemoFirebase, useUser, addDocumentNonBlocking } from '@/firebase';
import type { Class, Assignment } from '@/lib/types';
import { collection, doc } from 'firebase/firestore';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { PlusCircle, BookOpen } from 'lucide-react';

const assignmentFormSchema = z.object({
  name: z.string().min(1, 'Assignment name is required.'),
  description: z.string().min(1, 'Description is required.'),
});

function AddAssignmentDialog({ assignmentsRef, classId }: { assignmentsRef: any; classId: string }) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof assignmentFormSchema>>({
    resolver: zodResolver(assignmentFormSchema),
    defaultValues: {
      name: '',
      description: '',
    },
  });

  function onSubmit(values: z.infer<typeof assignmentFormSchema>) {
    if (!assignmentsRef) return;
    
    const newAssignmentData = {
        ...values,
        classId: classId,
    };

    addDocumentNonBlocking(assignmentsRef, newAssignmentData);

    toast({
      title: 'Assignment Created',
      description: `The assignment "${values.name}" has been successfully created.`,
    });
    form.reset();
    setOpen(false);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add New Assignment
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add New Assignment</DialogTitle>
          <DialogDescription>
            Enter the details for the new assignment. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Assignment Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Lab 1: Data Structures" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="A brief summary of the assignment requirements." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
                <DialogClose asChild>
                    <Button type="button" variant="secondary">
                        Cancel
                    </Button>
                </DialogClose>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                    {form.formState.isSubmitting ? 'Saving...' : 'Save Assignment'}
                </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}


export default function ClassDetailsPage({ params: { classId } }: { params: { classId: string } }) {
    const { user } = useUser();
    const firestore = useFirestore();

    const classRef = useMemoFirebase(() => {
        if (!user) return null;
        return doc(firestore, 'faculties', user.uid, 'classes', classId);
    }, [firestore, user, classId]);

    const { data: classData, isLoading: isLoadingClass } = useDoc<Class>(classRef);

    const assignmentsRef = useMemoFirebase(() => {
        if (!user || !classId) return null;
        return collection(firestore, 'faculties', user.uid, 'classes', classId, 'assignments');
    }, [firestore, user, classId]);

    const { data: assignments, isLoading: isLoadingAssignments } = useCollection<Assignment>(assignmentsRef);

    return (
        <div className="flex flex-col gap-6">
            {isLoadingClass ? (
                <div className="space-y-2">
                    <Skeleton className="h-9 w-64" />
                    <Skeleton className="h-5 w-96" />
                </div>
            ) : classData ? (
                <PageHeader
                    title={classData.name}
                    description={classData.description}
                />
            ) : (
                    <PageHeader
                    title="Class Not Found"
                    description="The class you are looking for does not exist or you do not have permission to view it."
                />
            )}

            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Assignments</CardTitle>
                    <CardDescription>Manage assignments for this class.</CardDescription>
                  </div>
                  <AddAssignmentDialog assignmentsRef={assignmentsRef} classId={classId} />
                </CardHeader>
                <CardContent>
                    {isLoadingAssignments ? (
                        <div className="space-y-4">
                            <Skeleton className="h-20 w-full" />
                            <Skeleton className="h-20 w-full" />
                        </div>
                    ) : assignments && assignments.length > 0 ? (
                        <div className="divide-y divide-border rounded-md border">
                            {assignments.map((assignment) => (
                                <div key={assignment.id} className="flex items-center justify-between p-4">
                                    <div className="flex items-center gap-4">
                                        <BookOpen className="h-6 w-6 text-muted-foreground" />
                                        <div className="flex-1">
                                            <p className="font-medium">{assignment.name}</p>
                                            <p className="text-sm text-muted-foreground">{assignment.description}</p>
                                        </div>
                                    </div>
                                    <Button variant="outline" size="sm" disabled>
                                        View Report
                                    </Button>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center text-muted-foreground p-8 border-2 border-dashed rounded-md">
                            <h3 className="text-xl font-semibold text-foreground mb-2">No Assignments Yet</h3>
                            <p className="text-sm">Click the button above to add your first assignment.</p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    )
}
