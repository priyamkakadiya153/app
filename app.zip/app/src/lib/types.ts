export interface Faculty {
    id: string;
    firebaseUid: string;
    firstName: string;
    lastName: string;
    email: string;
}

export interface Class {
    id: string;
    facultyId: string;
    name: string;
    description: string;
}

export interface Assignment {
    id: string;
    classId: string;
    name: string;
    description: string;
    starterCodeFileId?: string;
}

export interface Submission {
    id: string;
    assignmentId: string;
    studentName: string;
    fileUploadId: string;
}

export interface PlagiarismReport {
    id: string;
    assignmentId: string;
    reportDate: string;
    aiDetectionModelVersion: string;
}

export interface SimilarityAnalysis {
    id: string;
    plagiarismReportId: string;
    submission1Id: string;
    submission2Id: string;
    logicSimilarityPercentage: number;
    aiProbability: number;
    variableRenamingDetected: boolean;
    structureMatch: boolean;
}

export interface FileUpload {
    id: string;
    facultyId: string;
    filename: string;
    storagePath: string;
    uploadDate: string;
}
