'use server';

import { z } from 'zod';
import { randomUUID } from 'crypto';
import { initializeFirebase } from '@/firebase';
import { collection, doc, writeBatch, serverTimestamp } from 'firebase/firestore';
import type { PlagiarismReport, Submission, FileUpload } from '@/lib/types';


const SubmissionFileSchema = z.object({
  name: z.string(),
  content: z.string(),
});

const runAnalysisSchema = z.object({
  facultyId: z.string(),
  classId: z.string(),
  assignmentId: z.string(),
  submissions: z.array(SubmissionFileSchema),
  starterCode: z.string().optional(),
});

function getStudentNameFromFilename(filename: string): string {
    const parts = filename.split(/[\/\\_.-]/);
    return parts[0] || 'Unknown Student';
}

export async function runAnalysis(values: z.infer<typeof runAnalysisSchema>) {
    try {
        const validatedData = runAnalysisSchema.parse(values);
        const { facultyId, classId, assignmentId, submissions } = validatedData;
        const { firestore } = initializeFirebase();

        // 1. Create a new PlagiarismReport document to track this analysis job.
        const reportId = randomUUID();
        const reportRef = doc(firestore, 'faculties', facultyId, 'classes', classId, 'assignments', assignmentId, 'plagiarism_reports', reportId);
        const reportData: Omit<PlagiarismReport, 'id'> = {
            assignmentId: assignmentId,
            reportDate: new Date().toISOString(),
            aiDetectionModelVersion: 'gemini-2.5-flash', // Placeholder
        };

        // 2. Use a batch write for efficiency to create all submission and file records.
        const batch = writeBatch(firestore);
        
        batch.set(reportRef, reportData);

        for (const submissionFile of submissions) {
            const fileUploadId = randomUUID();
            const submissionId = randomUUID();
            
            // 3. Create a FileUpload record for each submission.
            const fileUploadRef = doc(firestore, 'file_uploads', fileUploadId);
            const fileUploadData: Omit<FileUpload, 'id'> = {
                facultyId: facultyId,
                filename: submissionFile.name,
                storagePath: `submissions/${reportId}/${submissionFile.name}`, // Placeholder path
                uploadDate: new Date().toISOString(),
            };
            batch.set(fileUploadRef, fileUploadData);

            // 4. Create a Submission record linking to the assignment and file.
            const submissionRef = doc(firestore, 'faculties', facultyId, 'classes', classId, 'assignments', assignmentId, 'submissions', submissionId);
            const submissionData: Omit<Submission, 'id'> = {
                assignmentId: assignmentId,
                studentName: getStudentNameFromFilename(submissionFile.name),
                fileUploadId: fileUploadId,
            };
            batch.set(submissionRef, submissionData);
        }

        // 5. Commit all the documents to Firestore in a single atomic operation.
        await batch.commit();

        // 6. Return the reportId so the client can redirect.
        // The actual analysis will be handled by a separate background process.
        return { success: true, reportId };

    } catch (error) {
        console.error("Error in runAnalysis:", error);
        if (error instanceof z.ZodError) {
            return { success: false, error: 'Invalid data provided.' };
        }
        return { success: false, error: 'An unexpected error occurred while setting up the analysis.' };
    }
}
