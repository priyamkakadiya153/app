'use server';

/**
 * @fileOverview An AI code suspicion score generator.
 *
 * - generateAISuspicionScore - A function that handles the AI suspicion score generation process.
 * - GenerateAISuspicionScoreInput - The input type for the generateAISuspicionScore function.
 * - GenerateAISuspicionScoreOutput - The return type for the generateAISuspicionScore function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateAISuspicionScoreInputSchema = z.object({
  code: z
    .string()
    .describe('The code to analyze.'),
});
export type GenerateAISuspicionScoreInput = z.infer<typeof GenerateAISuspicionScoreInputSchema>;

const GenerateAISuspicionScoreOutputSchema = z.object({
  aiSuspicionScore: z
    .number()
    .describe('The probability score (0-1) indicating potential AI-generated code.'),
});
export type GenerateAISuspicionScoreOutput = z.infer<typeof GenerateAISuspicionScoreOutputSchema>;

export async function generateAISuspicionScore(
  input: GenerateAISuspicionScoreInput
): Promise<GenerateAISuspicionScoreOutput> {
  return generateAISuspicionScoreFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateAISuspicionScorePrompt',
  input: {schema: GenerateAISuspicionScoreInputSchema},
  output: {schema: GenerateAISuspicionScoreOutputSchema},
  prompt: `You are an expert AI code detector.

You will analyze the given code and provide a probability score (0-1) indicating the likelihood of it being AI-generated. Consider factors like code style, structure, and common AI patterns.

Code: {{{code}}}`,
});

const generateAISuspicionScoreFlow = ai.defineFlow(
  {
    name: 'generateAISuspicionScoreFlow',
    inputSchema: GenerateAISuspicionScoreInputSchema,
    outputSchema: GenerateAISuspicionScoreOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
