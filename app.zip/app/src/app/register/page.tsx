'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Bot, UserPlus } from 'lucide-react';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useAuth, useFirestore, useUser, setDocumentNonBlocking } from '@/firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { doc } from 'firebase/firestore';
import { useEffect } from 'react';

const registerSchema = z.object({
  firstName: z.string().min(1, { message: 'First name is required' }),
  lastName: z.string().min(1, { message: 'Last name is required' }),
  email: z.string().email({ message: 'Invalid email address' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }),
});

type RegisterSchema = z.infer<typeof registerSchema>;

export default function RegisterPage() {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<RegisterSchema>({
    resolver: zodResolver(registerSchema),
  });
  const auth = useAuth();
  const firestore = useFirestore();
  const router = useRouter();
  const { toast } = useToast();
  const { user, isUserLoading } = useUser();

  useEffect(() => {
    if (user) {
      router.push('/dashboard');
    }
  }, [user, router]);
  
  const onSubmit: SubmitHandler<RegisterSchema> = async (data) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
      const user = userCredential.user;
      
      const facultyId = user.uid;
      const facultyRef = doc(firestore, 'faculties', facultyId);
      const facultyData = {
          id: facultyId,
          firebaseUid: facultyId,
          firstName: data.firstName,
          lastName: data.lastName,
          email: data.email,
      };

      setDocumentNonBlocking(facultyRef, facultyData, { merge: false });

      toast({
          title: 'Registration Successful',
          description: "You are now logged in and will be redirected.",
      });

    } catch (error: any) {
        toast({
            title: 'Registration Failed',
            description: error.message,
            variant: 'destructive',
        });
    }
  };

  if (isUserLoading || user) {
    return (
        <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4">
            <div className="flex items-center gap-2 text-lg font-semibold text-primary">
                <Bot className="h-8 w-8" />
                <span>Loading...</span>
            </div>
        </div>
    );
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <Card className="shadow-2xl">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <UserPlus className="h-8 w-8" />
            </div>
            <CardTitle className="font-headline text-3xl font-bold tracking-tight text-primary">
              Create Faculty Account
            </CardTitle>
            <CardDescription className="pt-2 text-base">
              Join CodeSleuth to start analyzing submissions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" {...register('firstName')} />
                   {errors.firstName && <p className="text-sm font-medium text-destructive">{errors.firstName.message}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" {...register('lastName')} />
                   {errors.lastName && <p className="text-sm font-medium text-destructive">{errors.lastName.message}</p>}
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="m@example.com" {...register('email')} />
                 {errors.email && <p className="text-sm font-medium text-destructive">{errors.email.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input id="password" type="password" {...register('password')} />
                 {errors.password && <p className="text-sm font-medium text-destructive">{errors.password.message}</p>}
              </div>
              <Button type="submit" className="w-full font-bold" disabled={isSubmitting}>
                 {isSubmitting ? 'Registering...' : 'Register'}
              </Button>
            </form>
            <div className="mt-4 text-center text-sm">
              Already have an account?{' '}
              <Link href="/login" className="underline">
                Login
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
       <footer className="absolute bottom-4 text-center text-xs text-muted-foreground">
        <p>&copy; {new Date().getFullYear()} CodeSleuth. All rights reserved.</p>
      </footer>
    </main>
  );
}
