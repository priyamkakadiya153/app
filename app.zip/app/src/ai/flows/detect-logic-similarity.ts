'use server';

/**
 * @fileOverview This file defines a Genkit flow for detecting logic similarity between two code snippets.
 *
 * The flow takes two code snippets as input and returns a similarity score and a list of detected similarities.
 *
 * @remarks
 *   - `detectLogicSimilarity`: The main function that initiates the logic similarity detection process.
 *   - `DetectLogicSimilarityInput`: The input type for the `detectLogicSimilarity` function.
 *   - `DetectLogicSimilarityOutput`: The output type for the `detectLogicSimilarity` function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

/**
 * Input schema for the logic similarity detection flow.
 */
const DetectLogicSimilarityInputSchema = z.object({
  code1: z.string().describe('First student code snippet for comparison.'),
  code2: z.string().describe('Second student code snippet for comparison.'),
  starterCode: z.string().optional().describe('Optional starter code to be ignored during analysis.'),
});

export type DetectLogicSimilarityInput = z.infer<typeof DetectLogicSimilarityInputSchema>;

/**
 * Output schema for the logic similarity detection flow.
 */
const DetectLogicSimilarityOutputSchema = z.object({
  similarityScore: z
    .number()
    .describe('A score indicating the similarity between the two code snippets (0-1).'),
  detectedSimilarities: z
    .array(z.string())
    .describe('A list of detected similarities, such as variable renaming or structure match.'),
  aiSuspicionProbability: z
    .number()
    .describe('The probability that at least one of the snippets contains AI-generated code (0-1).'),
});

export type DetectLogicSimilarityOutput = z.infer<typeof DetectLogicSimilarityOutputSchema>;

/**
 * Main function to detect logic similarity between two code snippets.
 * @param input - The input containing two code snippets.
 * @returns A promise resolving to the similarity score and detected similarities.
 */
export async function detectLogicSimilarity(
  input: DetectLogicSimilarityInput
): Promise<DetectLogicSimilarityOutput> {
  return detectLogicSimilarityFlow(input);
}

/**
 * Prompt definition for logic similarity detection.
 */
const detectLogicSimilarityPrompt = ai.definePrompt({
  name: 'detectLogicSimilarityPrompt',
  input: {schema: DetectLogicSimilarityInputSchema},
  output: {schema: DetectLogicSimilarityOutputSchema},
  prompt: `You are an expert code plagiarism detector for a university. Your task is to compare two student code submissions and determine if their logic is plagiarized.

**CRITICAL INSTRUCTIONS:**
1.  **Analyze Logic and Structure:** Your comparison MUST focus on the underlying logic, control flow (loops, conditionals), function calls, and order of operations.
2.  **Ignore Superficial Differences:** You MUST ignore differences in variable names, function names, comments, and code formatting (spacing, indentation). Simple renaming of variables should be flagged as a plagiarism indicator (e.g., "Variable Renaming Detected").
3.  **Exclude Starter Code:** If starter code is provided below, you MUST ignore it in your similarity analysis. Only compare the code written by the students themselves.
4.  **Provide Detailed Output:** Your output must be a JSON object with a `similarityScore` (0-1), `detectedSimilarities` (an array of strings like "Structural Match"), and an `aiSuspicionProbability` (0-1).

**Student Code Snippet 1:**
{{{code1}}}

**Student Code Snippet 2:**
{{{code2}}}

{{#if starterCode}}
**Starter Code to Ignore:**
{{{starterCode}}}
{{/if}}
`,
});

/**
 * Genkit flow for detecting logic similarity between two code snippets.
 */
const detectLogicSimilarityFlow = ai.defineFlow(
  {
    name: 'detectLogicSimilarityFlow',
    inputSchema: DetectLogicSimilarityInputSchema,
    outputSchema: DetectLogicSimilarityOutputSchema,
  },
  async input => {
    const {output} = await detectLogicSimilarityPrompt(input);
    return output!;
  }
);
