'use client';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileSearch, Users, Percent, Bot, Share2, BrainCircuit, GitCompareArrows, ShieldAlert } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AnimatedDownloadButton } from '@/components/ui/animated-download-button';

function StatCard({ title, value, icon: Icon, description }: { title: string, value: string | number, icon: React.ElementType, description: string }) {
    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{title}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{value}</div>
                <p className="text-xs text-muted-foreground">{description}</p>
            </CardContent>
        </Card>
    )
}


export default function ReportDetailsPage({ params }: { params: { reportId: string } }) {
  // TODO: This will be populated with plagiarism analysis data from Firestore for the specific reportId.
  // For now, we show a placeholder report.
  const report = {
    id: params.reportId,
    summary: {
      studentsAnalyzed: 27, // Placeholder
      highestSimilarity: 89, // Placeholder
      aiSuspected: 4, // Placeholder
    },
    detailedRows: [ // Placeholder
        { pair: ['student-a.js', 'student-c.js'], similarity: 89, aiProbability: 15, flags: ['High Similarity', 'Structure Match'] },
        { pair: ['student-b.py', 'student-d.py'], similarity: 72, aiProbability: 92, flags: ['AI Suspected', 'Variable Renaming'] },
        { pair: ['student-e.java', 'student-f.java'], similarity: 55, aiProbability: 5, flags: [] },
    ]
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Plagiarism Report"
        description={`Displaying analysis results for report ID: ${report.id}`}
      />

      {!report ? (
        <>
            <div className="flex flex-col items-center justify-center gap-4 rounded-md border-2 border-dashed border-muted bg-background/50 p-12 text-center">
                <FileSearch className="h-12 w-12 text-muted-foreground" />
                <div className="space-y-1">
                    <h3 className="text-xl font-semibold tracking-tight text-foreground">No Results Found</h3>
                    <p className="text-sm text-muted-foreground">
                        Could not find a report with this ID.
                    </p>
                </div>
                <Button asChild>
                    <Link href="/dashboard/upload">Start New Analysis</Link>
                </Button>
            </div>
        </>
      ) : (
        <div className="flex flex-col gap-6">
            <div className="grid gap-4 md:grid-cols-3">
                <StatCard title="Students Analyzed" value={report.summary.studentsAnalyzed} icon={Users} description="Total submissions in the batch." />
                <StatCard title="Highest Similarity" value={`${report.summary.highestSimilarity}%`} icon={Percent} description="The highest logic match found." />
                <StatCard title="AI-Suspected Count" value={report.summary.aiSuspected} icon={Bot} description="Submissions flagged for AI review." />
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle className="font-bold">Similarity Clusters</CardTitle>
                    <CardDescription>Visual graph of submission groups with high similarity. Groups in red indicate strong logic overlap.</CardDescription>
                </CardHeader>
                <CardContent className="h-64 flex items-center justify-center bg-secondary/30 rounded-md">
                    <p className="text-muted-foreground">[Similarity Cluster Graph Placeholder]</p>
                </CardContent>
            </Card>

            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle className="font-bold">Detailed Similarity Report</CardTitle>
                        <CardDescription>A breakdown of similarity scores between pairs of student submissions.</CardDescription>
                    </div>
                    <AnimatedDownloadButton />
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[25%]">Student Pair</TableHead>
                                <TableHead className="w-[25%]">Logic Similarity</TableHead>
                                <TableHead className="w-[20%]">AI Probability</TableHead>
                                <TableHead className="w-[20%]">Detected Flags</TableHead>
                                <TableHead className="text-right">Action</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                          {report.detailedRows.length > 0 ? report.detailedRows.map((row: any, index: number) => (
                            <TableRow key={index}>
                                <TableCell className="font-medium">{row.pair.join(' vs. ')}</TableCell>
                                <TableCell>
                                    <div className="flex items-center gap-2">
                                        <Progress value={row.similarity} className="w-full h-2" />
                                        <span className="text-xs font-mono text-muted-foreground w-12 text-right">{row.similarity}%</span>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className="flex items-center gap-2">
                                        <Progress value={row.aiProbability} className="w-full h-2" />
                                        <span className="text-xs font-mono text-muted-foreground w-12 text-right">{row.aiProbability}%</span>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className="flex gap-2">
                                        {row.flags.map((flag: string) => (
                                          <Badge key={flag} variant={flag === 'AI Suspected' || flag === 'High Similarity' ? 'destructive' : 'secondary'} className="text-xs">
                                              {flag === 'AI Suspected' && <ShieldAlert className="h-3 w-3 mr-1" />}
                                              {flag}
                                          </Badge>
                                        ))}
                                    </div>
                                </TableCell>
                                <TableCell className="text-right">
                                    <Button variant="outline" size="sm" asChild>
                                        <Link href={`/dashboard/comparison/${row.pair.join('/')}`}>View</Link>
                                    </Button>
                                </TableCell>
                            </TableRow>
                          )) : (
                            <TableRow>
                                <TableCell colSpan={5} className="text-center h-24">No results to display.</TableCell>
                            </TableRow>
                          )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
      )}
    </div>
  );
}
