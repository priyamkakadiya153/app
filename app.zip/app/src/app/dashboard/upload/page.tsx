'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { UploadCloud, File, X, Loader2, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import JSZip from 'jszip';
import { runAnalysis } from './actions';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import type { Class, Assignment } from '@/lib/types';
import { collection } from 'firebase/firestore';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

function FileUploader({
  label,
  description,
  onFileChange,
  file,
  clearFile,
  fileCount,
  accept,
  fileTypeHint,
}: {
  label: string;
  description?: string;
  onFileChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  file: File | null;
  clearFile: () => void;
  fileCount?: number | null;
  accept?: string;
  fileTypeHint: string;
}) {
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const id = label.replace(/\s/g, '');

  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      {description && <p className="text-xs text-muted-foreground pt-1">{description}</p>}
      {file ? (
        <div className="rounded-md border border-muted bg-secondary/50 p-3 mt-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <File className="h-5 w-5 text-muted-foreground" />
              <div className="flex flex-col">
                <span className="text-sm font-medium">{file.name}</span>
                <span className="text-xs text-muted-foreground">{formatFileSize(file.size)}</span>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={clearFile} className="h-6 w-6">
              <X className="h-4 w-4" />
            </Button>
          </div>
          {fileCount !== null && fileCount !== undefined && (
            <div className="mt-3 flex items-center gap-2 border-t border-muted-foreground/20 pt-3 text-sm font-medium text-emerald-600">
              <CheckCircle2 className="h-4 w-4" />
              <span>{fileCount} student files detected</span>
            </div>
          )}
        </div>
      ) : (
        <label
          htmlFor={id}
          className="mt-2 flex w-full cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-border bg-background/50 py-10 text-center transition hover:bg-muted/50"
        >
          <UploadCloud className="h-10 w-10 text-muted-foreground" />
          <p className="mt-2 text-sm text-muted-foreground">
            <span className="font-semibold text-primary">Click to upload</span> or drag and drop
          </p>
          <p className="text-xs text-muted-foreground">{fileTypeHint}</p>
          <Input id={id} type="file" className="hidden" onChange={onFileChange} accept={accept} />
        </label>
      )}
    </div>
  );
}

export default function UploadPage() {
  const { user } = useUser();
  const firestore = useFirestore();
  const router = useRouter();

  const [selectedClassId, setSelectedClassId] = useState<string | null>(null);
  const [selectedAssignmentId, setSelectedAssignmentId] = useState<string | null>(null);
  const [submissionsFile, setSubmissionsFile] = useState<File | null>(null);
  const [starterCodeFile, setStarterCodeFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [submissionFileCount, setSubmissionFileCount] = useState<number | null>(null);
  const { toast } = useToast();

  const classesRef = useMemoFirebase(() => {
    if (!user) return null;
    return collection(firestore, 'faculties', user.uid, 'classes');
  }, [firestore, user]);
  const { data: classes, isLoading: isLoadingClasses } = useCollection<Class>(classesRef);

  const assignmentsRef = useMemoFirebase(() => {
    if (!user || !selectedClassId) return null;
    return collection(firestore, 'faculties', user.uid, 'classes', selectedClassId, 'assignments');
  }, [firestore, user, selectedClassId]);
  const { data: assignments, isLoading: isLoadingAssignments } = useCollection<Assignment>(assignmentsRef);


  const handleSubmissionsChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const file = e.target.files[0];
      setSubmissionsFile(file);
      setSubmissionFileCount(null); // Reset on new file

      if (file && (file.type === 'application/zip' || file.type === 'application/x-zip-compressed')) {
        try {
          const zip = await JSZip.loadAsync(file);
          const fileCount = Object.values(zip.files).filter(
            (zipEntry) => !zipEntry.dir && !zipEntry.name.startsWith('__MACOSX') && !zipEntry.name.endsWith('.DS_Store')
          ).length;
          setSubmissionFileCount(fileCount);
        } catch (error) {
          console.error('Error reading zip file:', error);
          toast({
            title: 'Invalid ZIP file',
            description: 'Could not read the contents of the ZIP file. Please ensure it is not corrupted.',
            variant: 'destructive',
          });
          setSubmissionFileCount(null);
        }
      } else {
        setSubmissionFileCount(null);
      }
    }
  };

  const handleStarterCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) setStarterCodeFile(e.target.files[0]);
  };
  
  const clearSubmissionsFile = () => {
    setSubmissionsFile(null);
    setSubmissionFileCount(null);
    const input = document.getElementById('StudentSubmissions(ZIP)') as HTMLInputElement;
    if (input) input.value = '';
  }

  const clearStarterCodeFile = () => {
    setStarterCodeFile(null);
    const input = document.getElementById('StarterCode/QuestionFile(Optional)') as HTMLInputElement;
    if (input) input.value = '';
  }

  const handleAnalysis = async () => {
    if (!user || !submissionsFile || !selectedClassId || !selectedAssignmentId) {
      toast({
        title: 'Missing Information',
        description: 'Please select a class, an assignment, and upload the submissions file.',
        variant: 'destructive',
      });
      return;
    }
    setIsAnalyzing(true);
    
    const submissionFiles: { name: string; content: string }[] = [];
    try {
      const zip = await JSZip.loadAsync(submissionsFile);
      for (const filename in zip.files) {
        const zipEntry = zip.files[filename];
        if (!zipEntry.dir && !zipEntry.name.startsWith('__MACOSX') && !zipEntry.name.endsWith('.DS_Store')) {
          const content = await zipEntry.async('string');
          submissionFiles.push({ name: zipEntry.name, content });
        }
      }
    } catch (error) {
      console.error('Error processing zip file:', error);
      toast({
        title: 'Error Processing ZIP',
        description: 'There was a problem reading the submissions file.',
        variant: 'destructive',
      });
      setIsAnalyzing(false);
      return;
    }

    let starterCodeContent: string | undefined;
    if (starterCodeFile) {
      starterCodeContent = await starterCodeFile.text();
    }
    
    try {
      const result = await runAnalysis({
        facultyId: user.uid,
        classId: selectedClassId,
        assignmentId: selectedAssignmentId,
        submissions: submissionFiles,
        starterCode: starterCodeContent,
      });

      if (result.success && result.reportId) {
        toast({
            title: 'Analysis Queued',
            description: 'Your report is being generated. Redirecting to results...',
        });
        router.push(`/dashboard/results/${result.reportId}`);
      } else {
          throw new Error(result.error || 'The analysis could not be started.');
      }
    } catch (error) {
       console.error('Analysis failed:', error);
       toast({
        title: 'Analysis Failed',
        description: error instanceof Error ? error.message : 'The analysis could not be started. Please try again.',
        variant: 'destructive',
      });
      setIsAnalyzing(false);
    }
  };
  
  const getButtonState = () => {
    if (isAnalyzing) return { text: 'Queuing Analysis...', disabled: true };
    if (!selectedClassId) return { text: 'Select a Class', disabled: true };
    if (!selectedAssignmentId) return { text: 'Select an Assignment', disabled: true };
    if (!submissionsFile) return { text: 'Upload Submissions', disabled: true };
    return { text: 'Start Analysis', disabled: false };
  }

  const { text: buttonText, disabled: isButtonDisabled } = getButtonState();

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Upload Assignments"
        description="Bulk upload student code and optional starter files for analysis."
      />
      <Card>
        <CardHeader>
          <CardTitle>New Analysis</CardTitle>
          <CardDescription>
            Select the class and assignment, then upload the files for your new plagiarism check.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Class</Label>
                 <Select
                    onValueChange={(value) => {
                      setSelectedClassId(value);
                      setSelectedAssignmentId(null);
                    }}
                    disabled={isLoadingClasses}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={isLoadingClasses ? "Loading classes..." : "Select a class"} />
                    </SelectTrigger>
                    <SelectContent>
                      {classes?.map((cls) => (
                        <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
              </div>
              <div className="space-y-2">
                <Label>Assignment</Label>
                <Select
                    value={selectedAssignmentId || ''}
                    onValueChange={setSelectedAssignmentId}
                    disabled={!selectedClassId || isLoadingAssignments}
                >
                    <SelectTrigger>
                        <SelectValue placeholder={
                            isLoadingAssignments ? "Loading..." : 
                            !selectedClassId ? "First select a class" : "Select an assignment"
                        }/>
                    </Trigger>
                    <SelectContent>
                        {assignments?.map((assignment) => (
                            <SelectItem key={assignment.id} value={assignment.id}>{assignment.name}</SelectItem>
                        ))}
                         {assignments && assignments.length === 0 && selectedClassId && !isLoadingAssignments && (
                            <SelectItem value="no-assignments" disabled>No assignments found for this class.</SelectItem>
                        )}
                    </SelectContent>
                </Select>
              </div>
          </div>


          <FileUploader
            label="Student Submissions (ZIP)"
            file={submissionsFile}
            onFileChange={handleSubmissionsChange}
            clearFile={clearSubmissionsFile}
            fileCount={submissionFileCount}
            accept=".zip,application/zip,application/x-zip-compressed"
            fileTypeHint="ZIP file containing student submissions"
          />
          <FileUploader
            label="Starter Code / Question File (Optional)"
            description="Starter code is excluded from plagiarism checks to avoid false positives when all students use the same base code."
            file={starterCodeFile}
            onFileChange={handleStarterCodeChange}
            clearFile={clearStarterCodeFile}
            accept=".c,.cpp,.java,.py,.js,.ts,.txt,.md"
            fileTypeHint="Source code, text, or markdown files"
          />
          <div className="flex justify-end pt-2">
            <Button onClick={handleAnalysis} disabled={isButtonDisabled} size="lg">
              {isAnalyzing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {buttonText}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
