import { config } from 'dotenv';
config();

import '@/ai/flows/detect-logic-similarity.ts';
import '@/ai/flows/summarize-plagiarism-findings.ts';
import '@/ai/flows/generate-ai-suspicion-score.ts';