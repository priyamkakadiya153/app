// This file is intentionally left blank.
// The demo data has been removed and the application now uses live data from Firestore.
