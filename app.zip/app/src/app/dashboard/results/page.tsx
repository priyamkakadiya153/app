'use client';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileSearch, Users, Percent, Bot, Share2, BrainCircuit, GitCompareArrows, ShieldAlert } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AnimatedDownloadButton } from '@/components/ui/animated-download-button';

function StatCard({ title, value, icon: Icon, description }: { title: string, value: string | number, icon: React.ElementType, description: string }) {
    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{title}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{value}</div>
                <p className="text-xs text-muted-foreground">{description}</p>
            </CardContent>
        </Card>
    )
}


export default function ResultsPage() {
  // TODO: This will be populated with plagiarism analysis data from Firestore.
  // For now, we show the empty state if there are no results.
  const report = null;

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Plagiarism Reports"
        description="Browse all completed analysis reports."
      />

      {!report ? (
        <>
            <div className="flex flex-col items-center justify-center gap-4 rounded-md border-2 border-dashed border-muted bg-background/50 p-12 text-center">
                <FileSearch className="h-12 w-12 text-muted-foreground" />
                <div className="space-y-1">
                    <h3 className="text-xl font-semibold tracking-tight text-foreground">No Reports Found</h3>
                    <p className="text-sm text-muted-foreground">
                        You haven&apos;t analyzed any submissions yet.
                    </p>
                </div>
                <Button asChild>
                    <Link href="/dashboard/upload">Start First Analysis</Link>
                </Button>
            </div>
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="font-bold">What You’ll See Here</CardTitle>
                <CardDescription>Once you run an analysis, your report will include these powerful insights:</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-6 md:grid-cols-3">
                <div className="flex flex-col items-center text-center gap-2 p-4 rounded-md bg-secondary/50">
                    <Share2 className="h-8 w-8 text-primary" />
                    <h4 className="font-semibold">Code Similarity Clusters</h4>
                    <p className="text-xs text-muted-foreground">Visually identify groups of students with overlapping logic to quickly spot collaboration or copying.</p>
                </div>
                <div className="flex flex-col items-center text-center gap-2 p-4 rounded-md bg-secondary/50">
                    <BrainCircuit className="h-8 w-8 text-primary" />
                    <h4 className="font-semibold">AI Probability Flags</h4>
                    <p className="text-xs text-muted-foreground">Get a probability score on how likely a submission is to be AI-generated, helping you identify unusual code patterns.</p>
                </div>
                 <div className="flex flex-col items-center text-center gap-2 p-4 rounded-md bg-secondary/50">
                    <GitCompareArrows className="h-8 w-8 text-primary" />
                    <h4 className="font-semibold">Detailed Logic Comparison</h4>
                    <p className="text-xs text-muted-foreground">Dive deep with a side-by-side view of two submissions, with highlighted logic blocks that match.</p>
                </div>
              </CardContent>
            </Card>
        </>
      ) : (
        <div className="flex flex-col gap-6">
            {/* This section is now part of the dynamic report page /dashboard/results/[reportId] */}
        </div>
      )}
    </div>
  );
}
