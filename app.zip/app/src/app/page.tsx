import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Bot } from 'lucide-react';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <Card className="shadow-2xl">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <Bot className="h-8 w-8" />
            </div>
            <CardTitle className="font-headline text-3xl font-bold tracking-tight text-primary">
              CodeSleuth
            </CardTitle>
            <CardDescription className="pt-2 text-base">
              Intelligent Code Logic Similarity & Plagiarism Detection System
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center p-6 pt-0">
            <p className="mb-6 text-center text-sm text-muted-foreground">
              Welcome, faculty members. Log in to analyze student submissions for originality.
            </p>
            <Button asChild size="lg" className="w-full font-bold">
              <Link href="/login">Faculty Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
      <footer className="absolute bottom-4 text-center text-xs text-muted-foreground">
        <p>&copy; {new Date().getFullYear()} CodeSleuth. All rights reserved.</p>
      </footer>
    </main>
  );
}
