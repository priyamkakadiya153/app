export const firebaseConfig = {
  "projectId": "studio-1409259075-865fc",
  "appId": "1:32713671485:web:0eb2c6919114c1111d7b54",
  "apiKey": "AIzaSyAXWJVG0uLm9Am7vCazG7NNjDA4wT3nlAc",
  "authDomain": "studio-1409259075-865fc.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "32713671485"
};
