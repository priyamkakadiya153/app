'use client';
    
import { useState } from 'react';
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useUser, useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import type { Faculty } from '@/lib/types';
import { doc } from 'firebase/firestore';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Slider } from '@/components/ui/slider';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';


function ProfileForm({ faculty }: { faculty: Faculty }) {
    // For now, just display info. Edit functionality can be added later.
    return (
        <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input id="firstName" defaultValue={faculty.firstName} disabled />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input id="lastName" defaultValue={faculty.lastName} disabled />
                </div>
            </div>
            <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" defaultValue={faculty.email} disabled />
                <p className="text-xs text-muted-foreground pt-1">
                    Contact admin to change your email address.
                </p>
            </div>
            <div className="flex justify-end pt-2">
                <Button disabled>Save Changes</Button>
            </div>
        </form>
    )
}

export default function SettingsPage() {
    const { user } = useUser();
    const firestore = useFirestore();
    const [similarity, setSimilarity] = useState(75);

    const facultyRef = useMemoFirebase(() => {
    if (!user) return null;
    return doc(firestore, 'faculties', user.uid);
    }, [firestore, user]);

    const { data: faculty, isLoading } = useDoc<Faculty>(facultyRef);

    return (
    <div className="flex flex-col gap-6">
        <PageHeader
        title="Settings"
        description="Manage your account and profile settings."
        />
        <Card>
        <CardHeader>
            <CardTitle>Profile Settings</CardTitle>
            <CardDescription>This is how your information appears in the system.</CardDescription>
        </CardHeader>
        <CardContent>
            {isLoading ? (
            <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Skeleton className="h-4 w-16" />
                        <Skeleton className="h-10 w-full" />
                    </div>
                    <div className="space-y-2">
                        <Skeleton className="h-4 w-16" />
                        <Skeleton className="h-10 w-full" />
                    </div>
                </div>
                    <div className="space-y-2">
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-10 w-full" />
                </div>
                <div className="flex justify-end pt-2">
                    <Skeleton className="h-10 w-32" />
                </div>
            </div>
            ) : faculty ? (
            <ProfileForm faculty={faculty} />
            ) : (
            <p>Could not load profile information.</p>
            )}
        </CardContent>
        </Card>

        <Card>
            <CardHeader>
                <CardTitle>Analysis Preferences</CardTitle>
                <CardDescription>Customize the thresholds for plagiarism and AI detection.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8 pt-6">
                 <div className="space-y-3">
                    <Label htmlFor="similarity-threshold">Similarity Threshold ({similarity}%)</Label>
                    <div className="flex items-center gap-4 pt-1">
                        <Slider 
                            id="similarity-threshold" 
                            defaultValue={[similarity]} 
                            max={100} 
                            step={1} 
                            onValueChange={(value) => setSimilarity(value[0])}
                            disabled 
                        />
                    </div>
                    <p className="text-xs text-muted-foreground">Submissions with similarity above this will be flagged as high concern.</p>
                </div>

                <div className="space-y-3">
                    <Label>AI Warning Sensitivity</Label>
                    <RadioGroup defaultValue="medium" className="flex items-center gap-6 pt-2" disabled>
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="low" id="r1" />
                            <Label htmlFor="r1">Low</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="medium" id="r2" />
                            <Label htmlFor="r2">Medium</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="high" id="r3" />
                            <Label htmlFor="r3">High</Label>
                        </div>
                    </RadioGroup>
                     <p className="text-xs text-muted-foreground">Adjust the sensitivity of the AI-generated code detection model.</p>
                </div>
                <div className="flex justify-end pt-2">
                    <Button disabled>Save Preferences</Button>
                </div>
            </CardContent>
        </Card>
    </div>
    );
}
