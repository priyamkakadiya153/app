'use server';

/**
 * @fileOverview Summarizes plagiarism findings for a student submission, highlighting key indicators.
 *
 * - summarizePlagiarismFindings - A function that summarizes plagiarism findings.
 * - SummarizePlagiarismFindingsInput - The input type for the summarizePlagiarismFindings function.
 * - SummarizePlagiarismFindingsOutput - The return type for the summarizePlagiarismFindings function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizePlagiarismFindingsInputSchema = z.object({
  studentName: z.string().describe('The name of the student.'),
  logicSimilarityPercentage: z.number().describe('The logic similarity percentage with other submissions.'),
  aiProbability: z.number().describe('The probability that the code is AI-generated.'),
  variableRenamingDetected: z.boolean().describe('Whether variable renaming was detected.'),
  structureMatch: z.boolean().describe('Whether the code structure matches other submissions.'),
});
export type SummarizePlagiarismFindingsInput = z.infer<typeof SummarizePlagiarismFindingsInputSchema>;

const SummarizePlagiarismFindingsOutputSchema = z.object({
  summary: z.string().describe('A summary of the plagiarism findings for the student.'),
});
export type SummarizePlagiarismFindingsOutput = z.infer<typeof SummarizePlagiarismFindingsOutputSchema>;

export async function summarizePlagiarismFindings(
  input: SummarizePlagiarismFindingsInput
): Promise<SummarizePlagiarismFindingsOutput> {
  return summarizePlagiarismFindingsFlow(input);
}

const summarizePlagiarismFindingsPrompt = ai.definePrompt({
  name: 'summarizePlagiarismFindingsPrompt',
  input: {schema: SummarizePlagiarismFindingsInputSchema},
  output: {schema: SummarizePlagiarismFindingsOutputSchema},
  prompt: `Summarize the plagiarism findings for {{studentName}} based on the following information:\n\nLogic Similarity Percentage: {{logicSimilarityPercentage}}%\nAI Probability: {{aiProbability}}%\nVariable Renaming Detected: {{variableRenamingDetected}}\nStructure Match: {{structureMatch}}\n\nHighlight key indicators such as variable renaming, structure matching, and AI-suspected code.  Keep the summary to under 100 words.`,
});

const summarizePlagiarismFindingsFlow = ai.defineFlow(
  {
    name: 'summarizePlagiarismFindingsFlow',
    inputSchema: SummarizePlagiarismFindingsInputSchema,
    outputSchema: SummarizePlagiarismFindingsOutputSchema,
  },
  async input => {
    const {output} = await summarizePlagiarismFindingsPrompt(input);
    return output!;
  }
);
