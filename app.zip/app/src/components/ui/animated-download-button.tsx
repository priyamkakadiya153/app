'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Loader2, Check } from 'lucide-react';
import { Button } from './button';
import { cn } from '@/lib/utils';

type DownloadStatus = 'idle' | 'downloading' | 'success';

export function AnimatedDownloadButton() {
  const [status, setStatus] = useState<DownloadStatus>('idle');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (status !== 'downloading') {
      setProgress(0);
      return;
    }

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setStatus('success');
          setTimeout(() => setStatus('idle'), 2000);
          return 100;
        }
        return prev + 5;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [status]);

  const handleDownload = () => {
    if (status === 'idle') {
      setStatus('downloading');
    }
  };

  return (
    <Button
      onClick={handleDownload}
      disabled={status !== 'idle'}
      className={cn(
        'relative w-40 h-10 overflow-hidden transition-all duration-300 ease-in-out',
        {
          'bg-primary/90': status === 'downloading',
          'bg-emerald-600 hover:bg-emerald-700': status === 'success',
        }
      )}
      aria-live="polite"
    >
      <AnimatePresence mode="wait">
        {status === 'idle' && (
          <motion.div
            key="idle"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            <span>Download</span>
          </motion.div>
        )}
        {status === 'downloading' && (
          <motion.div
            key="downloading"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="flex items-center gap-2"
          >
            <Loader2 className="h-4 w-4 animate-spin" />
            <span>Downloading</span>
          </motion.div>
        )}
        {status === 'success' && (
          <motion.div
            key="success"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="flex items-center gap-2"
          >
            <Check className="h-4 w-4" />
            <span>Downloaded</span>
          </motion.div>
        )}
      </AnimatePresence>
      {status === 'downloading' && (
        <motion.div
          className="absolute bottom-0 left-0 h-full bg-primary/50"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ ease: 'linear', duration: 0.2 }}
        />
      )}
    </Button>
  );
}
