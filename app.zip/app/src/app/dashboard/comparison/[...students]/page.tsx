import { notFound } from 'next/navigation';

export default function ComparisonPage({ params }: { params: { students: string[] } }) {

  // TODO: This page will be implemented to fetch and compare two specific submissions from Firestore.
  // For now, we will show a not found page, since there is no data to compare.
  notFound();

  return null;
}
